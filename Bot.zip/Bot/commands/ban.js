const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a user from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to ban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('The reason for the ban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Ban duration (e.g., 5s, 5m, 5h, 5d, perm)')
                .setRequired(true)),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        // Check if bot has ban permissions
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({
                content: '❌ I do not have permission to ban members. Please give me the "Ban Members" permission.',
                ephemeral: true
            });
        }

        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason');
        const duration = interaction.options.getString('duration');

        // Check if the target user is bannable
        const member = await interaction.guild.members.fetch(user.id).catch(() => null);
        if (member && !member.bannable) {
            return interaction.reply({
                content: '❌ I cannot ban this user. They may have higher permissions than me.',
                ephemeral: true
            });
        }

        // Parse duration
        let banDuration = 0;
        if (duration.toLowerCase() !== 'perm') {
            const timeValue = parseInt(duration.slice(0, -1));
            const timeUnit = duration.slice(-1).toLowerCase();
            
            switch (timeUnit) {
                case 's': banDuration = timeValue * 1000; break;
                case 'm': banDuration = timeValue * 60 * 1000; break;
                case 'h': banDuration = timeValue * 60 * 60 * 1000; break;
                case 'd': banDuration = timeValue * 24 * 60 * 60 * 1000; break;
                default:
                    return interaction.reply({
                        content: '❌ Invalid duration format. Use: 5s, 5m, 5h, 5d, or perm',
                        ephemeral: true
                    });
            }
        }

        try {
            // Try to send DM before banning
            try {
                const userEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🚫 You have been banned')
                    .setDescription(`You have been banned from ${interaction.guild.name}`)
                    .addFields(
                        { name: '📝 Reason', value: reason },
                        { name: '⏱️ Duration', value: duration === 'perm' ? 'Permanent' : duration }
                    )
                    .setTimestamp();

                await user.send({ embeds: [userEmbed] });
            } catch (error) {
                console.log('Could not send DM to user before ban');
            }

            // Ban the user
            await interaction.guild.members.ban(user, { reason: reason });

            // Create ban embed
            const banEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🚫 User Banned')
                .addFields(
                    { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                    { name: '📝 Reason', value: reason, inline: true },
                    { name: '⏱️ Duration', value: duration === 'perm' ? 'Permanent' : duration, inline: true },
                    { name: '🛡️ Banned by', value: `${interaction.user.tag}`, inline: true }
                )
                .setTimestamp();

            // Send log to ban log channel
            const logChannel = await interaction.client.channels.fetch('1373660410296664184');
            if (logChannel) {
                await logChannel.send({ embeds: [banEmbed] });
            }

            // Reply to command
            await interaction.reply({
                content: `✅ Successfully banned ${user.tag}`,
                ephemeral: true
            });

            // If temporary ban, set timeout to unban
            if (duration !== 'perm' && banDuration > 0) {
                setTimeout(async () => {
                    try {
                        await interaction.guild.members.unban(user, 'Ban duration expired');
                        
                        // Send unban log
                        const unbanEmbed = new EmbedBuilder()
                            .setColor('#00ff00')
                            .setTitle('✅ User Unbanned')
                            .addFields(
                                { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                                { name: '📝 Reason', value: 'Ban duration expired', inline: true }
                            )
                            .setTimestamp();

                        // Send unban log to specific channel
                        const unbanChannel = await interaction.client.channels.fetch('1373664346563153972');
                        if (unbanChannel) {
                            await unbanChannel.send({ embeds: [unbanEmbed] });
                        }

                        // Send DM to unbanned user
                        try {
                            const unbanUserEmbed = new EmbedBuilder()
                                .setColor('#00ff00')
                                .setTitle('✅ You have been unbanned')
                                .setDescription(`Your ban from ${interaction.guild.name} has expired`)
                                .setTimestamp();

                            await user.send({ embeds: [unbanUserEmbed] });
                        } catch (error) {
                            console.log('Could not send DM to unbanned user');
                        }
                    } catch (error) {
                        console.error('Error unbanning user:', error);
                    }
                }, banDuration);
            }
        } catch (error) {
            console.error('Error banning user:', error);
            await interaction.reply({
                content: '❌ There was an error while banning the user. Make sure I have the necessary permissions.',
                ephemeral: true
            });
        }
    },
}; 