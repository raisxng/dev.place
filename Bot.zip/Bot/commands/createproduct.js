const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('createproduct')
        .setDescription('Create a product form for users to purchase'),

    async execute(interaction) {
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const modal = new ModalBuilder()
            .setCustomId('createproduct_modal')
            .setTitle('Create Product');

        const titleInput = new TextInputBuilder()
            .setCustomId('product_title')
            .setLabel('Product Title')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const descInput = new TextInputBuilder()
            .setCustomId('product_description')
            .setLabel('Product Description')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        const thumbInput = new TextInputBuilder()
            .setCustomId('product_thumbnail')
            .setLabel('Thumbnail Image Link (image)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const videoInput = new TextInputBuilder()
            .setCustomId('product_video')
            .setLabel('Demo Video Link (optional)')
            .setStyle(TextInputStyle.Short)
            .setRequired(false);

        const buttonInput = new TextInputBuilder()
            .setCustomId('product_button')
            .setLabel('Button Name (e.g., Buy Now)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(titleInput),
            new ActionRowBuilder().addComponents(descInput),
            new ActionRowBuilder().addComponents(thumbInput),
            new ActionRowBuilder().addComponents(videoInput),
            new ActionRowBuilder().addComponents(buttonInput)
        );

        await interaction.showModal(modal);
    },
}; 