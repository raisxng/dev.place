const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('message')
        .setDescription('Send a custom message'),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        // Create the modal
        const modal = new ModalBuilder()
            .setCustomId('messageModal')
            .setTitle('Send Message');

        // Add input field
        const messageInput = new TextInputBuilder()
            .setCustomId('messageInput')
            .setLabel('Your Message')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Type your message here...')
            .setRequired(true);

        // Create action row and add the input
        const firstActionRow = new ActionRowBuilder().addComponents(messageInput);

        // Add the action row to the modal
        modal.addComponents(firstActionRow);

        // Show the modal
        await interaction.showModal(modal);
    },
}; 