const { SlashCommandBuilder, EmbedBuilder, InteractionResponseFlags } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Clear messages in the current channel')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Number of messages to delete (max 100)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(100)),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const amount = interaction.options.getInteger('amount');

        try {
            // Defer the reply since bulk delete might take some time
            await interaction.deferReply({ ephemeral: true });

            // Fetch messages
            const messages = await interaction.channel.messages.fetch({ limit: amount });
            
            // Delete messages
            await interaction.channel.bulkDelete(messages);

            // Create success embed
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🧹 Messages Cleared')
                .setDescription(`Successfully deleted ${messages.size} messages`)
                .setTimestamp();

            // Send confirmation
            await interaction.editReply({ embeds: [embed] });

            // Delete the confirmation after 5 seconds
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch (error) {
                    console.log('Could not delete confirmation message');
                }
            }, 5000);

        } catch (error) {
            console.error('Error clearing messages:', error);
            await interaction.editReply({
                content: '❌ There was an error while clearing messages.',
                ephemeral: true
            });
        }
    },
}; 