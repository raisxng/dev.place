const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Create a ticket system message'),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor('#4c4c55')
            .setTitle('Services Center - dev.place')
            .setDescription('📧 **Support:**\nTo start your service, select an option below. To speed up the process, please inform us about the subject of the service and attach images if necessary.\n\n💬 **Service Hours:**\nService only from 7am to 9pm. (**UTC−3**)\n\n💬 **Working Hours:**\nWork only from 5:20pm to 9pm. (**UTC−3**)')
            .setImage('https://cdn.discordapp.com/attachments/1373728308037943536/1373815836099477554/support.png?ex=682bc933&is=682a77b3&hm=81143ba337f5c9723d4031017dbc479deae47677d6db61872d7be88b1426b2cf&')

        const row = new ActionRowBuilder()
            .addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('ticket_select')
                    .setPlaceholder('Select ticket type')
                    .addOptions([
                        {
                            label: 'Questions',
                            description: 'Need help? Click here.',
                            value: 'ticket_questions',
                            emoji: '❓'
                        },
                        {
                            label: 'Others',
                            description: 'Other subject? Click here.',
                            value: 'ticket_others',
                            emoji: '📝'
                        }
                    ])
            );

        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: 'Ticket system created!', ephemeral: true });
    },
}; 