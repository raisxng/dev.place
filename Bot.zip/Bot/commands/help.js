const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Shows all available commands'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('Bot Commands')
            .setDescription('Here are all available commands:')
            .addFields(
                { name: '/ping', value: 'Check if the bot is responsive' },
                { name: '/help', value: 'Show this help message' }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
}; 