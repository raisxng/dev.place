const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Create a custom embed message'),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        // Create the modal
        const modal = new ModalBuilder()
            .setCustomId('embedModal')
            .setTitle('Create Embed');

        // Add input fields
        const titleInput = new TextInputBuilder()
            .setCustomId('titleInput')
            .setLabel('Title')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter the embed title')
            .setRequired(false);

        const descriptionInput = new TextInputBuilder()
            .setCustomId('descriptionInput')
            .setLabel('Description')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Enter the embed description')
            .setRequired(false);

        const colorInput = new TextInputBuilder()
            .setCustomId('colorInput')
            .setLabel('Color (hex code)')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter hex color (e.g., #780dac)')
            .setValue('#780dac')
            .setRequired(false);

        const footerInput = new TextInputBuilder()
            .setCustomId('footerInput')
            .setLabel('Footer')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter the footer text')
            .setRequired(false);

        const imageInput = new TextInputBuilder()
            .setCustomId('imageInput')
            .setLabel('Image URL')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Enter an image URL')
            .setRequired(false);

        // Add inputs to action rows
        const firstActionRow = new ActionRowBuilder().addComponents(titleInput);
        const secondActionRow = new ActionRowBuilder().addComponents(descriptionInput);
        const thirdActionRow = new ActionRowBuilder().addComponents(colorInput);
        const fourthActionRow = new ActionRowBuilder().addComponents(footerInput);
        const fifthActionRow = new ActionRowBuilder().addComponents(imageInput);

        // Add action rows to modal
        modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow);

        // Show the modal
        await interaction.showModal(modal);

        // Handle modal submission
        const filter = i => i.customId === 'embedModal';
        try {
            const submission = await interaction.awaitModalSubmit({ filter, time: 300000 });

            // Get the values from the modal
            const title = submission.fields.getTextInputValue('titleInput');
            const description = submission.fields.getTextInputValue('descriptionInput');
            const color = submission.fields.getTextInputValue('colorInput') || '#780dac';
            const footer = submission.fields.getTextInputValue('footerInput');
            const imageUrl = submission.fields.getTextInputValue('imageInput');

            // Create the embed
            const embed = new EmbedBuilder()
                .setColor(color);

            if (title) embed.setTitle(title);
            if (description) embed.setDescription(description);
            if (footer) embed.setFooter({ text: footer });
            if (imageUrl) embed.setImage(imageUrl);

            // Send the embed as a new message
            await interaction.channel.send({ embeds: [embed] });
            
            // Acknowledge the submission without showing a reply
            await submission.deferUpdate();
        } catch (error) {
            console.error('Error handling embed modal:', error);
            if (error.code === 'INTERACTION_COLLECTOR_ERROR') {
                await interaction.followUp({
                    content: '❌ Embed creation timed out. Please try again.',
                    ephemeral: true
                });
            }
        }
    },
}; 