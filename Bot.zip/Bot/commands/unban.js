const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a user from the server')
        .addStringOption(option =>
            option.setName('userid')
                .setDescription('The ID of the user to unban')
                .setRequired(true)),

    async execute(interaction) {
        // Check if user is admin
        if (interaction.user.id !== config.adminId) {
            return interaction.reply({
                content: '❌ You do not have permission to use this command.',
                ephemeral: true
            });
        }

        // Check if bot has ban permissions
        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({
                content: '❌ I do not have permission to unban members. Please give me the "Ban Members" permission.',
                ephemeral: true
            });
        }

        const userId = interaction.options.getString('userid');

        try {
            // Try to fetch the user first
            const user = await interaction.client.users.fetch(userId).catch(() => null);
            
            if (!user) {
                return interaction.reply({
                    content: '❌ Could not find a user with that ID.',
                    ephemeral: true
                });
            }

            // Check if the user is actually banned
            const bans = await interaction.guild.bans.fetch();
            const bannedUser = bans.find(ban => ban.user.id === userId);

            if (!bannedUser) {
                return interaction.reply({
                    content: '❌ This user is not banned.',
                    ephemeral: true
                });
            }

            // Unban the user
            await interaction.guild.members.unban(userId, `Unbanned by ${interaction.user.tag}`);

            // Create unban embed
            const unbanEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ User Unbanned')
                .addFields(
                    { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                    { name: '🛡️ Unbanned by', value: `${interaction.user.tag}`, inline: true }
                )
                .setTimestamp();

            // Send log to unban log channel
            const logChannel = await interaction.client.channels.fetch('1373664346563153972');
            if (logChannel) {
                await logChannel.send({ embeds: [unbanEmbed] });
            }

            // Try to send DM to unbanned user
            try {
                const userEmbed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ You have been unbanned')
                    .setDescription(`You have been unbanned from ${interaction.guild.name}`)
                    .setTimestamp();

                await user.send({ embeds: [userEmbed] });
            } catch (error) {
                console.log('Could not send DM to unbanned user');
            }

            // Reply to command
            await interaction.reply({
                content: `✅ Successfully unbanned ${user.tag}`,
                ephemeral: true
            });

        } catch (error) {
            console.error('Error unbanning user:', error);
            await interaction.reply({
                content: '❌ There was an error while unbanning the user. Make sure I have the necessary permissions.',
                ephemeral: true
            });
        }
    },
}; 