module.exports = {
    token: 'MTM3MzY1MzEyNDg5NTYwODk0Mg.GRfKX6.0GM5sQ1H-adr-a_NNp0Wx_SUxiP3VuPPlnal2A',
    guildId: '1331000113937645629',
    adminId: '1088946006663630969'
}; 