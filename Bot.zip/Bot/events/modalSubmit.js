const { Events } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (!interaction.isModalSubmit()) return;

        if (interaction.customId === 'messageModal') {
            const messageContent = interaction.fields.getTextInputValue('messageInput');

            try {
                // Send the message
                await interaction.channel.send(messageContent);
                
                // Reply to the command (ephemeral so only the command user sees it)
                await interaction.reply({
                    content: '✅ Message sent successfully!',
                    ephemeral: true
                });
            } catch (error) {
                console.error('Error sending message:', error);
                await interaction.reply({
                    content: '❌ There was an error while sending the message.',
                    ephemeral: true
                });
            }
        }
    },
}; 