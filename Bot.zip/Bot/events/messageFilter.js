const { Events, PermissionsBitField, EmbedBuilder } = require('discord.js');
const config = require('../config');

// User warning counter
const userWarnings = new Map();

// Bad words list (both Portuguese and English)
const badWords = [
    // Portuguese
    'p[o0]rr?a', 'c[a@]r[a@]lh[o0]', 'p[uú]t[a4@]', 'm[e3]rd[a4@]', 'f[o0]d[a4@]', 'b[uú]c[e3]t[a4@]', 'c[a@]c[e3]t[e3]', 'c[a@]r[a@]i', 'v[i1]ad[o0]', 'bait[o0]l[a4@]', 'pau', 'r[o0]l[a4@]', 'p[i1]nt[o0]', 'p[e3ê]n[i1]s', 'v[a4@]d[i1]a', 'put[i1]nh[a4@]', 'put[a4@]o', 'p[qk]p', 'f[o0]d[a4@]', 'b[i1]ch[a4@]', 'p[o0]rr[a4@]', 'merd[a4@]',
    
    // English
    'f[uú*]c[kq]', 's[h*]i[t7]', 'b[i1!]t[ch]', 'a[s$]{2}', 'd[i1]ck', 'p[uú]ss[y1i!]', 'c[uú]nt', 'wh[o0]r[e3]', 'sl[uú]t', 'b[a@]st[a@]rd', 'motherf[uú*]c[kq]er', 'dumb[a@]ss', 'idi[o0]t', 'st[uú]p[i1]d', 'ret[a@]rd', 'tw[a@]t', 'c[o0]ck', 'w[a@]nk[e3]r', 'd[i1]ckhead',

    // Racism
    'pr[e3]t[o0]', 'n[e3]gr[a@]o', 'n[i1]gg[a@e3r]', 'mac[a@]c[o0]', 'monk[e3]y', 'j[e3]w', 'j[e3]w[i1]sh', 'k[i1]k[e3]', 'sp[i1]c', 'w[e3]tb[a@]ck', 'ch[i1]nk',

    // Homophobia
    'f[a@]gg[o0][t7]', 'f[a@]g', 'q[uú]e[e3]r', 'd[y1]k[e3]', 'l[e3]sb[o0]', 'h[o0]m[o0]'
];


class MessageFilter {
    constructor(client) {
        this.client = client;
        this.initialize();
    }

    initialize() {
        this.client.on(Events.MessageCreate, this.handleMessage.bind(this));
        console.log('Message filter system initialized!');
    }

    async sendLogEmbed(channel, user, message, action, warningCount) {
        const logChannel = await this.client.channels.fetch('1373660454462685214');
        if (!logChannel) return;

        const embed = new EmbedBuilder()
            .setColor(action === 'deleted' ? '#ff0000' : '#ff9900')
            .setTitle(`${action === 'deleted' ? '🚫' : '⚠️'} Message ${action}`)
            .setDescription(`A message containing inappropriate language was ${action}`)
            .addFields(
                { name: '👤 User', value: `${user.tag} (${user.id})`, inline: true },
                { name: '📝 Message', value: message.content, inline: false },
                { name: '📊 Warnings', value: `${warningCount}/5`, inline: true }
            )
            .setTimestamp();

        await logChannel.send({ embeds: [embed] });
    }

    async handleMessage(message) {
        // Ignore messages from bots and DMs
        if (message.author.bot || !message.guild) return;

        // Check if message is from the admin
        if (message.author.id === config.adminId) return;

        try {
            // Check if message contains bad words
            const messageContent = message.content.toLowerCase();
            const containsBadWord = badWords.some(pattern => {
                const regex = new RegExp(pattern, 'i');
                return regex.test(messageContent);
            });            

            if (containsBadWord) {
                // Check if bot has permissions
                if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
                    console.error('Bot lacks permission to delete messages');
                    return;
                }

                // Delete the message immediately
                await message.delete();
                
                // Send warning to user
                const warning = await message.channel.send({
                    content: `⚠️ ${message.author}, your message has been removed for containing inappropriate language.`
                });

                // Increment warning counter
                const currentWarnings = userWarnings.get(message.author.id) || 0;
                const newWarnings = currentWarnings + 1;
                userWarnings.set(message.author.id, newWarnings);

                // Send log with updated warning count
                await this.sendLogEmbed(message.channel, message.author, message, 'deleted', newWarnings);

                // Delete warning after 3 seconds
                setTimeout(() => warning.delete().catch(() => {}), 3000);

                // If user has 5 warnings, ban them
                if (newWarnings >= 5) {
                    try {
                        // Check if bot has ban permissions
                        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
                            console.error('Bot lacks permission to ban members');
                            return;
                        }

                        // Try to send DM before banning
                        try {
                            const banEmbed = new EmbedBuilder()
                                .setColor('#ff0000')
                                .setTitle('🚫 You have been banned')
                                .setDescription('You have been banned from the server for excessive use of inappropriate language.')
                                .setTimestamp();

                            await message.author.send({ embeds: [banEmbed] });
                        } catch (dmError) {
                            console.log('Could not send DM to user');
                        }

                        // Fetch the member before banning
                        const member = await message.guild.members.fetch(message.author.id);
                        await member.ban({ reason: 'Excessive inappropriate language' });
                        
                        // Send ban notification to channel
                        const banMessage = await message.channel.send(`🚫 ${message.author.tag} has been banned for excessive inappropriate language.`);
                        setTimeout(() => banMessage.delete().catch(() => {}), 5000);
                    } catch (error) {
                        console.error('Error banning user:', error);
                    }
                } else {
                    // Send warning count to user's DM
                    try {
                        const warningEmbed = new EmbedBuilder()
                            .setColor('#ff9900')
                            .setTitle('⚠️ Warning')
                            .setDescription(`Warning ${newWarnings}/5: Your message was removed for containing inappropriate language.`)
                            .addFields(
                                { name: '⚠️ Note', value: 'You will be banned after 5 warnings.' }
                            )
                            .setTimestamp();

                        await message.author.send({ embeds: [warningEmbed] });
                    } catch (dmError) {
                        console.log('Could not send DM to user');
                    }
                }
            }
        } catch (error) {
            console.error('Error handling message:', error);
        }
    }
}

module.exports = MessageFilter; 