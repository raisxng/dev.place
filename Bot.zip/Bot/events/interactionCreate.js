const { Events, ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../config');
const fs = require('fs');
const path = require('path');
const purchaseDataPath = path.join(__dirname, '../purchaseData.json');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        // --- PRODUCT FORM HANDLER ---
        if (interaction.isModalSubmit() && interaction.customId === 'createproduct_modal') {
            const title = interaction.fields.getTextInputValue('product_title');
            const description = interaction.fields.getTextInputValue('product_description');
            const thumbnail = interaction.fields.getTextInputValue('product_thumbnail');
            const video = interaction.fields.getTextInputValue('product_video');
            const buttonName = interaction.fields.getTextInputValue('product_button');

            const embed = new EmbedBuilder()
                .setColor('#4c4c55')
                .setTitle(title)
                .setDescription(description)
                .setImage(thumbnail)
                .setTimestamp();

            const buyButton = new ButtonBuilder()
                .setCustomId(`product_buy_${Date.now()}`)
                .setLabel(buttonName)
                .setStyle(ButtonStyle.Success);

            let row;
            if (video && video.trim() !== '') {
                row = new ActionRowBuilder()
                    .addComponents(
                        buyButton,
                        new ButtonBuilder()
                            .setLabel('View Demo')
                            .setStyle(ButtonStyle.Link)
                            .setURL(video)
                            .setDisabled(false)
                    );
            } else {
                row = new ActionRowBuilder().addComponents(buyButton);
            }

            await interaction.channel.send({ embeds: [embed], components: [row] });
            await interaction.reply({ content: 'Product form created!', ephemeral: true });
            return;
        }

        // --- PRODUCT BUY BUTTON HANDLER ---
        if (interaction.isButton() && interaction.customId.startsWith('product_buy_')) {
            // Cria canal privado na categoria do ticket
            const categoryId = '1373674492865548429';
            const productTitle = interaction.message.embeds[0]?.title || 'Product';
            const productImage = interaction.message.embeds[0]?.image?.url || '';

            // Verifica se já existe canal para o usuário e produto
            const existing = interaction.guild.channels.cache.find(c => c.name === `order-${interaction.user.username}` && c.parentId === categoryId);
            if (existing) {
                return interaction.reply({ content: `You already have an open order: ${existing}`, ephemeral: true });
            }

            // Garante que o adminId é válido
            const adminId = String(config.adminId);
            const adminMember = interaction.guild.members.cache.get(adminId);
            const adminRole = interaction.guild.roles.cache.get(adminId);
            const overwrites = [
                {
                    id: String(interaction.guild.id),
                    deny: [PermissionFlagsBits.ViewChannel],
                },
                {
                    id: String(interaction.user.id),
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                },
                {
                    id: String(interaction.client.user.id),
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                }
            ];
            if (adminMember || adminRole) {
                overwrites.push({
                    id: adminId,
                    allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                });
            }
            const channel = await interaction.guild.channels.create({
                name: `order-${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: categoryId,
                permissionOverwrites: overwrites,
            });

            // Salva o autor do pedido no topic
            await channel.setTopic(`Order opened by: ${interaction.user.id}`);

            // Menciona o admin ao criar o canal
            if (config.adminId) {
                await channel.send(`<@${config.adminId}>`);
            }

            const orderEmbed = new EmbedBuilder()
                .setColor('#4c4c55')
                .setTitle(`Order: ${productTitle}`)
                .setImage(productImage)

            const finalizeRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('finalize_order')
                        .setLabel('Finalize Purchase')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅')
                );

            await channel.send({ embeds: [orderEmbed], components: [finalizeRow] });
            await interaction.reply({ content: `Your order channel has been created: ${channel}`, ephemeral: true });
            return;
        }

        // --- FINALIZE ORDER BUTTON HANDLER ---
        if (interaction.isButton() && interaction.customId === 'finalize_order') {
            if (interaction.user.id !== config.adminId) {
                return interaction.reply({
                    content: '❌ Only administrators can finalize purchases.',
                    ephemeral: true
                });
            }

            await interaction.deferUpdate();

            // Buscar o autor do pedido pelo topic do canal
            let orderAuthorId = null;
            if (interaction.channel.topic && interaction.channel.topic.startsWith('Order opened by: ')) {
                orderAuthorId = interaction.channel.topic.replace('Order opened by: ', '').trim();
            }

            // Enviar mensagem de avaliação ao usuário no canal de compra
            if (orderAuthorId) {
                try {
                    const user = await interaction.client.users.fetch(orderAuthorId);
                    const closeEmbed = new EmbedBuilder()
                        .setColor('#4c4c55')
                        .setTitle('PURCHASE COMPLETED')
                        .addFields(
                            { name: '🛒 Purchase finalized by:', value: `${interaction.user.tag}`, inline: false },
                            { name: '🕒 Time:', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: false }
                        )
                        .setDescription('Thank you for your purchase at dev.place!')
                        .setThumbnail('https://cdn.discordapp.com/attachments/1373728308037943536/1373809653355380736/Server.png?ex=682bc371&is=682a71f1&hm=37a13f6998c44b40001172a5f119a3ca6c9b569f50ad2f830683fe57f7c09bd9&');
                    await user.send({ embeds: [closeEmbed] });
                } catch (e) {
                    console.log('Could not send DM to order author.');
                }
            }

            // Enviar mensagem para o canal de log de compras
            let logMessage;
            try {
                const logChannel = await interaction.client.channels.fetch('1373685036163006578');
                if (logChannel) {
                    const orderTitle = interaction.message.embeds[0]?.title?.replace('Order: ', '') || 'Product';
                    const orderUser = interaction.guild.members.cache.get(orderAuthorId);
                    const logEmbed = new EmbedBuilder()
                        .setColor('#4c4c55')
                        .setAuthor({
                            name: orderUser ? orderUser.user.username : 'User',
                            iconURL: orderUser ? orderUser.user.displayAvatarURL() : undefined
                        })
                        .setDescription(`🛒 **Purchase Completed!**\n**Cart**\n\`${orderTitle}\``)
                        .setTimestamp();
                    logMessage = await logChannel.send({ embeds: [logEmbed] });
                }
            } catch (e) {
                console.log('Could not send log to purchase channel.');
            }

            // Send rating message in English in the order channel and mention the user
            try {
                const ratingRow = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId('rate_1').setLabel('1 ⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('rate_2').setLabel('2 ⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('rate_3').setLabel('3 ⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('rate_4').setLabel('4 ⭐').setStyle(ButtonStyle.Secondary),
                        new ButtonBuilder().setCustomId('rate_5').setLabel('5 ⭐').setStyle(ButtonStyle.Secondary)
                    );
                await interaction.channel.send({
                    content: `<@${orderAuthorId}> Rate your purchase experience with us!\nYour feedback is very important to us!`,
                    components: [ratingRow]
                });
            } catch (e) {
                console.log('Could not send rating message.');
            }

            // Do NOT send any message to the admin who clicked finalize.
            return;
        }

        // --- RATING HANDLER ---
        if (interaction.isButton() && interaction.customId.startsWith('rate_')) {
            const stars = parseInt(interaction.customId.replace('rate_', ''));
            const starStr = '⭐'.repeat(stars);
            // Buscar o comprador real pelo topic do canal
            let orderAuthorId = null;
            if (interaction.channel.topic && interaction.channel.topic.startsWith('Order opened by: ')) {
                orderAuthorId = interaction.channel.topic.replace('Order opened by: ', '').trim();
            } else {
                orderAuthorId = interaction.user.id;
            }
            // Update the last purchase embed in the purchase channel
            let orderTitle = '';
            try {
                const logChannel = await interaction.client.channels.fetch('1373685036163006578');
                if (logChannel) {
                    const messages = await logChannel.messages.fetch({ limit: 10 });
                    let orderUser = interaction.guild.members.cache.get(orderAuthorId);
                    let logMsg = messages.find(m => m.embeds[0]?.author?.name === orderUser?.user.username);
                    if (logMsg) {
                        const oldEmbed = logMsg.embeds[0];
                        orderTitle = oldEmbed.description?.match(/`([^`]+)`/)?.[1] || 'Product';
                        const newEmbed = EmbedBuilder.from(oldEmbed)
                            .setDescription(`${oldEmbed.description}\n**Rating:**\n${starStr} (${stars}/5)`);
                        await logMsg.edit({ embeds: [newEmbed] });
                    } else {
                        orderTitle = 'Product';
                        const logEmbed = new EmbedBuilder()
                            .setColor('#4c4c55')
                            .setAuthor({
                                name: orderUser ? orderUser.user.username : 'User',
                                iconURL: orderUser ? orderUser.user.displayAvatarURL() : undefined
                            })
                            .setDescription(`🛒 **Purchase Completed!**\n**Cart**\n\`${orderTitle}\`\n**Rating:**\n${starStr} (${stars}/5)`)
                            .setTimestamp();
                        await logChannel.send({ embeds: [logEmbed] });
                    }
                }
            } catch (e) {
                console.log('Could not update rating in purchase channel.');
            }
            // Send the 'Thank you' embed only to the user who rated
            const closeEmbed = new EmbedBuilder()
                .setColor('#00b300')
                .setTitle('Purchase Finalized')
                .setDescription('Thank you for your purchase!')
            await interaction.reply({ embeds: [closeEmbed], ephemeral: true });

            // Give role 1373692747986501712 to the comprador
            try {
                const member = await interaction.guild.members.fetch(orderAuthorId);
                await member.roles.add('1373692747986501712');
            } catch (e) {
                console.log('Could not give purchase role.');
            }

            // Count purchases and give loyalty role if needed
            let purchaseData = {};
            try {
                if (fs.existsSync(purchaseDataPath)) {
                    purchaseData = JSON.parse(fs.readFileSync(purchaseDataPath, 'utf8'));
                }
            } catch (e) { purchaseData = {}; }
            purchaseData[orderAuthorId] = (purchaseData[orderAuthorId] || 0) + 1;
            try {
                fs.writeFileSync(purchaseDataPath, JSON.stringify(purchaseData, null, 2));
            } catch (e) { console.log('Could not save purchase data.'); }
            if (purchaseData[orderAuthorId] === 5) {
                try {
                    const member = await interaction.guild.members.fetch(orderAuthorId);
                    await member.roles.add('1373693562025283635');
                } catch (e) {
                    console.log('Could not give loyalty role.');
                }
            }

            setTimeout(async () => {
                try {
                    await interaction.channel.delete();
                } catch (error) {
                    console.error('Error deleting order channel:', error);
                }
            }, 5000);
            return;
        }

        // --- TICKET SYSTEM ---
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'ticket_select') {
                const ticketType = interaction.values[0].split('_')[1];
                const categoryId = '1373674492865548429';
                const category = await interaction.guild.channels.fetch(categoryId);
                
                if (!category) {
                    return interaction.reply({
                        content: '❌ Could not find the ticket category.',
                        ephemeral: true
                    });
                }

                // Garante que o adminId é válido
                const adminId = String(config.adminId);
                const adminMember = interaction.guild.members.cache.get(adminId);
                const adminRole = interaction.guild.roles.cache.get(adminId);
                const overwrites = [
                    {
                        id: String(interaction.guild.id),
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: String(interaction.user.id),
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    },
                    {
                        id: String(interaction.client.user.id),
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    }
                ];
                if (adminMember || adminRole) {
                    overwrites.push({
                        id: adminId,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    });
                }
                const channel = await interaction.guild.channels.create({
                    name: `ticket-${interaction.user.username}`,
                    type: ChannelType.GuildText,
                    parent: categoryId,
                    permissionOverwrites: overwrites,
                });

                // Salvar o autor do ticket no canal para uso posterior
                await channel.setTopic(`Ticket opened by: ${interaction.user.id}`);

                // Menciona o admin ao criar o canal
                if (config.adminId) {
                    await channel.send(`<@${config.adminId}>`);
                }

                const ticketEmbed = new EmbedBuilder()
                    .setColor('#4c4c55')
                    .setTitle('Ticket Created')
                    .setDescription(`Welcome to your ticket, ${interaction.user}!
Our team will assist you shortly. Please provide all necessary information about your issue.
**Ticket Type:** ${ticketType === 'questions' ? 'Questions' : 'Others'}
**Created by:** ${interaction.user.tag}`)
                    .setImage('https://cdn.discordapp.com/attachments/1373728308037943536/1373815836099477554/support.png?ex=682bc933&is=682a77b3&hm=81143ba337f5c9723d4031017dbc479deae47677d6db61872d7be88b1426b2cf&')
                    .setTimestamp();

                const closeButton = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('close_ticket')
                            .setLabel('Close Ticket')
                            .setStyle(ButtonStyle.Danger)
                            .setEmoji('🔒')
                    );

                await channel.send({ embeds: [ticketEmbed], components: [closeButton] });
                await interaction.reply({ content: `Your ticket has been created: ${channel}`, ephemeral: true });
            }
        }

        // --- CLOSE TICKET ---
        if (interaction.isButton() && interaction.customId === 'close_ticket') {
            if (interaction.user.id !== config.adminId) {
                return interaction.reply({
                    content: '❌ Only administrators can close tickets.',
                    ephemeral: true
                });
            }

            let ticketAuthorId = null;
            if (interaction.channel.topic && interaction.channel.topic.startsWith('Ticket opened by: ')) {
                ticketAuthorId = interaction.channel.topic.replace('Ticket opened by: ', '').trim();
            }

            if (ticketAuthorId) {
                try {
                    const user = await interaction.client.users.fetch(ticketAuthorId);
                    const closeEmbed = new EmbedBuilder()
                        .setColor('#4c4c55')
                        .setTitle('SERVICE FINISHED')
                        .addFields(
                            { name: '🗨️ Ticket closed by:', value: `${interaction.user.tag}`, inline: false },
                            { name: '🕒 Time:', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: false }
                        )
                        .setDescription('We hope you had a good service at dev.place!')
                        .setThumbnail('https://cdn.discordapp.com/attachments/1373728308037943536/1373809653355380736/Server.png?ex=682bc371&is=682a71f1&hm=37a13f6998c44b40001172a5f119a3ca6c9b569f50ad2f830683fe57f7c09bd9&');
                    await user.send({ embeds: [closeEmbed] });
                } catch (e) {
                    console.log('Could not send DM to ticket author.');
                }
            }

            const closeEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('Ticket Closing')
                .setDescription('This ticket will be closed in 5 seconds.')

            await interaction.reply({ embeds: [closeEmbed] });

            setTimeout(async () => {
                try {
                    await interaction.channel.delete();
                } catch (error) {
                    console.error('Error deleting ticket channel:', error);
                }
            }, 5000);
        }
    },
}; 