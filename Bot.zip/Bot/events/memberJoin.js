const { Events } = require('discord.js');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {
            // Get the role by ID
            const role = member.guild.roles.cache.get('1373666584903548929');
            
            if (!role) {
                console.error('Role not found');
                return;
            }

            // Add the role to the member
            await member.roles.add(role);
            console.log(`Added role to ${member.user.tag}`);
        } catch (error) {
            console.error('Error adding role to member:', error);
        }
    },
}; 